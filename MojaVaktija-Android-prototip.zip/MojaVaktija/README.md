# Moja Vaktija — Android početni prototip

Ovo je početni Android Studio projekat (Kotlin + Jetpack Compose) za aplikaciju Moja Vaktija, namijenjenu lokaciji Brčko.

## Trenutno uključeno
- Početni ekran na bosanskom jeziku
- Vizuelni raspored za dnevna namaska vremena
- Prekidači za ezan i obavijesti (trenutno samo vizuelni prototip)
- Link ka Vaktija.ba
- Android dozvole za internet, obavijesti i zakazivanje tačnih alarma

## Važno
Ovo još NIJE gotova aplikacija za svakodnevnu upotrebu i ne generiše APK. Namaska vremena namjerno nisu izmišljena. Potrebno je potvrditi dozvoljen i stabilan način preuzimanja podataka sa Vaktija.ba, implementirati osvježavanje podataka, dodati audio-snimak ezana uz odgovarajuća prava korištenja, stvarno zakazivanje alarma i testiranje na uređajima.

## Otvaranje
1. Instaliraj Android Studio na računar.
2. Izaberi **Open** i otvori ovaj folder.
3. Sačekaj Gradle Sync.
4. Pokreni na emulatoru ili povezanom Android telefonu.

Cilj je prvo povezati pouzdan izvor vaktije za Brčko, a zatim implementirati pouzdane ezan-alarm obavijesti koje rade u pozadini.
