package ba.mojavaktija.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.OpenInBrowser
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Forest = Color(0xFF102B25)
private val ForestCard = Color(0xFF234239)
private val Gold = Color(0xFFD6B779)
private val Cream = Color(0xFFF7F4EC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MojaVaktijaScreen(onOpenSource = {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://vaktija.ba/")))
        }) }
    }
}

@Composable
fun MojaVaktijaScreen(onOpenSource: () -> Unit) {
    var adhanEnabled by remember { mutableStateOf(true) }
    var notificationsEnabled by remember { mutableStateOf(true) }
    var showInfo by remember { mutableStateOf(true) }

    MaterialTheme(colorScheme = lightColorScheme(primary = Forest, secondary = Gold, background = Cream)) {
        Surface(modifier = Modifier.fillMaxSize(), color = Cream) {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = PaddingValues(18.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.size(54.dp).background(Gold, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) {
                            Text("☾", color = Forest, fontSize = 34.sp, fontWeight = FontWeight.Bold)
                        }
                        Column(Modifier.weight(1f)) {
                            Text("Moja Vaktija", fontSize = 25.sp, fontWeight = FontWeight.Bold, color = Forest)
                            Text("Brčko · Bosna i Hercegovina", color = Color(0xFF61736B), fontSize = 14.sp)
                        }
                        Icon(Icons.Default.Settings, contentDescription = "Postavke", tint = Forest)
                    }
                }
                item {
                    Column(
                        Modifier.fillMaxWidth().background(Forest, RoundedCornerShape(24.dp)).padding(22.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text("VAKTIJA ZA DANAS", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                        Text("Esselamu alejkum", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.SemiBold)
                        Text("Namaska vremena će se prikazati nakon povezivanja izvora Vaktija.ba.", color = Color(0xFFE1E9E4), fontSize = 14.sp, lineHeight = 20.sp)
                        Spacer(Modifier.height(4.dp))
                        OutlinedButton(onClick = onOpenSource, colors = ButtonDefaults.outlinedButtonColors(contentColor = Gold)) {
                            Icon(Icons.Default.OpenInBrowser, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Otvori Vaktija.ba")
                        }
                    }
                }
                item {
                    Text("Namaska vremena", color = Forest, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(horizontal = 16.dp)) {
                        listOf("Zora / Sabah", "Izlazak sunca", "Podne", "Ikindija", "Akšam", "Jacija").forEachIndexed { index, name ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(name, Modifier.weight(1f), color = Forest, fontSize = 16.sp)
                                Text("—:—", color = Color(0xFF7D8983), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                            }
                            if (index != 5) HorizontalDivider(color = Color(0xFFE9EDE9))
                        }
                    }
                }
                item {
                    Text("Obavijesti", color = Forest, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Column(Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(18.dp)).padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = Forest)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Ezan za svaki namaz", color = Forest, fontWeight = FontWeight.SemiBold)
                                Text("Reprodukcija ezana u vrijeme namaza", color = Color(0xFF69766F), fontSize = 12.sp)
                            }
                            Switch(checked = adhanEnabled, onCheckedChange = { adhanEnabled = it })
                        }
                        HorizontalDivider(Modifier.padding(vertical = 10.dp), color = Color(0xFFE9EDE9))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Obavijesti na telefonu", color = Forest, fontWeight = FontWeight.SemiBold)
                                Text("Podsjetnik za nastupanje namaza", color = Color(0xFF69766F), fontSize = 12.sp)
                            }
                            Switch(checked = notificationsEnabled, onCheckedChange = { notificationsEnabled = it })
                        }
                    }
                }
                item {
                    if (showInfo) {
                        Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFECE5D4))) {
                            Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Napomena za probnu verziju", color = Forest, fontWeight = FontWeight.Bold)
                                Text("Ovo je početni prototip izgleda. Vremena, preuzimanje vaktije i stvarno puštanje ezana još nisu povezani — crtice nisu namaska vremena.", color = Forest, fontSize = 13.sp, lineHeight = 19.sp)
                                TextButton(onClick = { showInfo = false }) { Text("Razumijem", color = Forest) }
                            }
                        }
                    }
                    Text("Izvor namjere: Vaktija.ba · Lokacija: Brčko", color = Color(0xFF7D8983), fontSize = 12.sp, modifier = Modifier.padding(bottom = 8.dp))
                }
            }
        }
    }
}
